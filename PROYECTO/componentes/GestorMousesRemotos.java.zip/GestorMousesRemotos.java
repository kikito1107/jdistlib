package componentes;

import javax.swing.*;

import interfaces.*;
import Deventos.*;
import Deventos.enlaceJS.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import untitled1.*;
import util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class GestorMousesRemotos
	 implements DComponente {
  private Integer DID = null;
  private String nombre = null;
  private ColaEventos colaRecepcion = new ColaEventos();
  private ColaEventos colaEnvio = null;
  private boolean activo = false;
  protected JFrame frame = null;
  protected Point p = new Point();

  //private PanelMouses panelMouses = new PanelMouses();
  private ConjuntoMousesRemotos conjuntoMouses = new ConjuntoMousesRemotos();
  private int nivelPermisos = 20;

  int x = 20;

  public GestorMousesRemotos(JFrame frame) {
	 this.frame = frame;
	 DID = new Integer(DConector.alta(this));
	 colaEnvio = DConector.getColaEventos();
  }

  public void activar() {}

  public void desactivar() {}

  public void iniciarHebraProcesadora() {

  }

  public void procesarEvento(DEvent evento) {
	 colaRecepcion.nuevoEvento(evento);
  }

  public void sincronizar() {
	 DMouseEvent evento = new DMouseEvent();

	 evento.origen = new Integer(1); // Aplicacion
	 evento.destino = new Integer(0); // Coordinador
	 evento.componente = new Integer(DID.intValue());
	 evento.tipo = new Integer(DMouseEvent.PETICION_INFORMACION.intValue());
	 colaEnvio.nuevoEvento(evento);

	 Thread p = new Thread(new HebraProcesadora(this));
	 p.start();
  }

  public void setNivelPermisos(int nivel) {
	 nivelPermisos = nivel;
  }

  public Integer getID() {
	 return DID;
  }

  public String getNombre(){
	 return nombre;
}
  private void nuevoMouse(String usuario, Point posicion) {
  }

  private class Borrar implements Runnable{
		public void run() {
		  while(true){
			 try{
				Thread.currentThread().sleep(1500);
			 }catch(Exception e){

}
			 x += 10;
			 frame.getContentPane().repaint();
		  }
		}

}


  private class ConjuntoMousesRemotos {
	 private Vector v = new Vector();

	 public synchronized void nuevoMouse(String usuario, Point posicion) {
		MouseRemoto mr = new MouseRemoto(usuario, 2, posicion, 50, 15);
		//panelMouses.add(mr,JLayeredPane.POPUP_LAYER);
		frame.getGlassPane().repaint();
		v.add(mr);
	 }

	 public synchronized void eliminarUsuario(String usuario) {
		MouseRemoto mr = null;
		int pos = buscar(usuario);
		if (pos >= 0) { // El usuario existe
		  //mr = (MouseRemoto) v.elementAt(pos);
		  //panelMouses.remove(mr);
		  v.removeElementAt(pos);
		}
	 }

	 public synchronized void decrementarContadores() {
		MouseRemoto mr = null;
		for (int i = (v.size() - 1); i >= 0; i--) {
		  mr = (MouseRemoto) v.elementAt(i);
		  mr.decrementarContador();
		  if (mr.contadorAgotado()) {
			 //panelMouses.remove(mr);
			 v.removeElementAt(i);
		  }
		}
	 }

	 public synchronized void actualizarMouse(String usuario, Point posicion) {
		MouseRemoto mr = null;
		int pos = buscar(usuario);
		if (pos >= 0) { // El usuario existe
		  mr = (MouseRemoto) v.elementAt(pos);
		  //mr.setBounds(posicion.x, posicion.y, mr.ancho(),mr.alto());
		  //System.out.println(frame.getContentPane().getComponentCount());
		  //frame.getContentPane().repaint();
		  //frame.repaint();//**************************************************
		  mr.posicion.x = posicion.x;
		  mr.posicion.y = posicion.y;
		  mr.reiniciarContador();
		}
	 }

	 public synchronized boolean existe(String usuario) {
		MouseRemoto mr = null;
		boolean existe = false;
		int posicion = buscar(usuario);

		if (posicion >= 0)
		  existe = true;

		return existe;
	 }

	 public synchronized Vector obtenerMousesRemotos() {
		Vector vector = new Vector();
		for (int i = 0; i < v.size(); i++) {
		  vector.add(v.elementAt(i));
		}
		return vector;
	 }

	 private int buscar(String usuario) {
		MouseRemoto mr = null;
		int posicion = -1;
		for (int i = 0; i < v.size(); i++) {
		  mr = (MouseRemoto) v.elementAt(i);
		  if (mr.usuario.equals(usuario)) {
			 posicion = i;
		  }
		}
		return posicion;
	 }
  }

  private class MouseRemoto {
	 public Point posicion = new Point();
	 Dimension dim = new Dimension();
	 int contador = -1;
	 int timeout = -1;
	 String usuario = null;

	 MouseRemoto(String usuario, int contador, Point posicion, int ancho,
					 int alto) {
		this.usuario = new String(usuario);
		this.contador = contador;
		this.timeout = contador;
		this.posicion.x = posicion.x;
		this.posicion.y = posicion.y;
		this.dim.width = ancho;
		this.dim.height = alto;
		//this.setBounds(posicion.x, posicion.y, ancho,alto);
	 }

	 void decrementarContador() {
		contador--;
	 }

	 void reiniciarContador() {
		contador = timeout;
	 }

	 boolean contadorAgotado() {
		return (contador <= 0);
	 }

	 int ancho() {
		return dim.width;
	 }

	 int alto() {
		return dim.height;
	 }
  }




/*  class GlassPane
		extends JComponent {

	 protected void paintComponent(Graphics g) {
		Image img = new ImageIcon(MensajesIni.class.getResource("puntero.gif")).
			 getImage();
		Point posTexto = new Point();
		g.setColor(Color.red);
//				  g.fillOval(50, 50, 20, 20);
		Vector mouses = conjuntoMouses.obtenerMousesRemotos();
		MouseRemoto mr = null;
		for (int i = 0; i < mouses.size(); i++) {
		  mr = (MouseRemoto) mouses.elementAt(i);
		  //g.drawString(mr.usuario, mr.posicion.x, mr.posicion.y);
		  //aux = SwingUtilities.convertPoint(frame.getGlassPane(),mr.posicion,frame.getContentPane());
		  g.drawImage(img, mr.posicion.x, mr.posicion.y, null);
		  posTexto.x = mr.posicion.x + 15;
		  posTexto.y = mr.posicion.y + 20;
		  g.drawString(mr.usuario, posTexto.x, posTexto.y);
		}
	 }
  }

  /*private class PanelMouses
	  extends JPanel {//**************************************************************************
		public PanelMouses() {
		super();
		try {
	  jbInit();
		}
		catch (Exception ex) {
	  ex.printStackTrace();
		}
		}

		void jbInit() throws Exception {
		//this.setLayout(null);
		//this.addMouseMotionListener(new ListenerPanelMouses());
		}
		}*/

	/*private void redispatchMouseEvent(MouseEvent e) {
	  //	 System.out.println("Redispatch");
	  Point glassPanePoint = e.getPoint();
	  Container container = frame.getContentPane();
	  Point containerPoint = SwingUtilities.convertPoint(
			frame.getGlassPane(),
			glassPanePoint,
			frame.getContentPane());

	  if (containerPoint.y < 0) { //we're not in the content pane
		 //Could have special code to handle mouse events over
		 //the menu bar or non-system window decorations, such as
		 //the ones provided by the Java look and feel.
	  }
	  else {
		 //The mouse event is probably over the content pane.
		 //Find out exactly which component it's over.
		 Component component =
			  SwingUtilities.getDeepestComponentAt(
			  container,
			  containerPoint.x,
			  containerPoint.y);

		 if ( (component != null)) {
			//Forward events over the check box.
			Point componentPoint = SwingUtilities.convertPoint(
				 frame.getGlassPane(),
				 glassPanePoint,
				 component);
			component.dispatchEvent(new MouseEvent(component,
																e.getID(),
																e.getWhen(),
																e.getModifiers(),
																componentPoint.x,
																componentPoint.y,
																e.getClickCount(),
																e.isPopupTrigger()));
		 }
	  }
	}

  class ListenerPanelMouses
		extends java.awt.event.MouseMotionAdapter {

	 ListenerPanelMouses() {
	 }

	 public void mouseDragged(MouseEvent e) {
		redispatchMouseEvent(e);
	 }

	 public void mouseMoved(MouseEvent e) {
		redispatchMouseEvent(e);
		p.x = e.getX();
		p.y = e.getY();
		frame.getGlassPane().repaint();
		//System.out.println("Actualizada posicion a "+p.x+","+p.y);
	 }
  }

  class ListenerPanelMouses2
		extends java.awt.event.MouseAdapter {

	 ListenerPanelMouses2() {
	 }

	 public void mouseClicked(MouseEvent e) {
		redispatchMouseEvent(e);
	 }

	 public void mouseEntered(MouseEvent e) {
		redispatchMouseEvent(e);
	 }

	 public void mouseExited(MouseEvent e) {
		redispatchMouseEvent(e);
	 }

	 public void mousePressed(MouseEvent e) {
		redispatchMouseEvent(e);
	 }

	 public void mouseReleased(MouseEvent e) {
		redispatchMouseEvent(e);
	 }
  }*/

  /**
	* Esta hebra se encarga de realizar las operaciones pertinentes con los
	* eventos que se reciben
*/
  class HebraProcesadora
		implements Runnable {

	 GestorMousesRemotos gestor = null;

	 HebraProcesadora(GestorMousesRemotos gestor) {
		this.gestor = gestor;
	 }

	 public void run() {
		DMouseEvent evento = null;
		Thread t = new Thread(new HebraGestora(gestor));
		t.start();

		while (true) {
		  evento = (DMouseEvent) colaRecepcion.extraerEvento();
		  //System.out.println("HebraProcesadora: Recibido evento del tipo "+evento.tipo);
		  if (evento.tipo.intValue() == DMouseEvent.PETICION_INFORMACION.intValue()) {
			 DMouseEvent aux = new DMouseEvent();
			 aux.origen = new Integer(1); // Aplicacion
			 aux.destino = new Integer(0); // Coordinador
			 aux.componente = new Integer(DID.intValue());
			 aux.tipo = new Integer(DMouseEvent.CAMBIO_POSICION.intValue());
			 aux.px = new Integer(p.x);
			 aux.py = new Integer(p.y);

			 colaEnvio.nuevoEvento(aux);
		  }
		  if (evento.tipo.intValue() == DMouseEvent.CAMBIO_POSICION.intValue()) {
			 if (!evento.usuario.equals(DConector.usuario)) {
				System.out.println("Actualizado mouse del usuario " +
										 evento.usuario);
				conjuntoMouses.actualizarMouse(evento.usuario,
														 new Point(evento.px.intValue(),
					 evento.py.intValue()));
				frame.getGlassPane().repaint();

				//System.out.println("Actualizada posicion del usuario "+evento.usuario+" a "+evento.px+","+evento.py);
				if (!conjuntoMouses.existe(evento.usuario)) {
				  System.out.println("A�adido usuario " + evento.usuario);
				  conjuntoMouses.nuevoMouse(evento.usuario,
													 new Point(evento.px.intValue(),
																  evento.py.intValue()));
				}

			 }
		  }
		}
	 }
  }

  /**
	* Se encarga de comunicar cada X tiempo nuestra posicion del mouse y eliminar
	* mouses de usuarios que ya no estan presentes
*/
  class HebraGestora
		implements Runnable {
	 int tiempoActualizacion = 50; // Milisegundos
	 int tiempoPeticion = 60000; // Milisegundos
	 int tiempoRestante = 60000; // Milisegundos
	 GestorMousesRemotos gestor = null;
	 Point ultimaEnviada = new Point();

	 HebraGestora(GestorMousesRemotos gestor) {
		this.gestor = gestor;
	 }

	 public void run() {
		while (true) {
		  try {
			 Thread.currentThread().sleep(tiempoActualizacion);
			 tiempoRestante -= tiempoActualizacion;
			 DMouseEvent evento = new DMouseEvent();

			 // Solo enviamos la posicion actual si ha cambiado desde el ultimo
			 // envio
			 if (p.x != ultimaEnviada.x || p.y != ultimaEnviada.y) {
				evento.origen = new Integer(1); // Aplicacion
				evento.destino = new Integer(0); // Coordinador
				evento.componente = new Integer(DID.intValue());
				evento.tipo = new Integer(DMouseEvent.CAMBIO_POSICION.intValue());
				evento.px = new Integer(p.x);
				evento.py = new Integer(p.y);
				colaEnvio.nuevoEvento(evento);

				ultimaEnviada.x = p.x;
				ultimaEnviada.y = p.y;
			 }

			 if (tiempoRestante <= 0) {
				evento = new DMouseEvent();
				evento.origen = new Integer(1); // Aplicacion
				evento.destino = new Integer(0); // Coordinador
				evento.componente = new Integer(DID.intValue());
				evento.tipo = new Integer(DMouseEvent.PETICION_INFORMACION.intValue());
				evento.px = new Integer(p.x);
				evento.py = new Integer(p.y);
				colaEnvio.nuevoEvento(evento);

				conjuntoMouses.decrementarContadores();
				frame.getGlassPane().repaint(); // Por si se ha eliminado algun mouse
				tiempoRestante = tiempoPeticion;
			 }

		  }
		  catch (Exception e) {
			 e.printStackTrace();
		  }
		}
	 }
  }

}
